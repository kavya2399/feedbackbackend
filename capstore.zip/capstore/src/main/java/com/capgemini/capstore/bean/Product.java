package com.capgemini.capstore.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="product")
public class Product {

	@Id
	@Column(name="prod_Id")
	private long prod_Id;
	@Column(name="prod_Name")
	private String prodName;
	@Column(name="prod_Price")
	private double prodPrice;
	@Column(name="prod_Quantity")
	private long prodQuantity;
	@Column(name="prod_Discount")
	private double prodDiscount;
	@Column(name="prod_Category")
	private String prodCategory;
	@Column(name="prod_Desc")
	private String prodDesc;
	public long getProdId() {
		return prod_Id;
	}
	public void setProdId(long prod_Id) {
		this.prod_Id = prod_Id;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public double getProdPrice() {
		return prodPrice;
	}
	public void setProdPrice(double prodPrice) {
		this.prodPrice = prodPrice;
	}
	public long getProdQuantity() {
		return prodQuantity;
	}
	public void setProdQuantity(long prodQuantity) {
		this.prodQuantity = prodQuantity;
	}
	public double getProdDiscount() {
		return prodDiscount;
	}
	public void setProdDiscount(double prodDiscount) {
		this.prodDiscount = prodDiscount;
	}
	public String getProdCategory() {
		return prodCategory;
	}
	public void setProdCategory(String prodCategory) {
		this.prodCategory = prodCategory;
	}
	public String getProdDesc() {
		return prodDesc;
	}
	public void setProdDesc(String prodDesc) {
		this.prodDesc = prodDesc;
	}
	public String getProdImage() {
		return prodImage;
	}
	public void setProdImage(String prodImage) {
		this.prodImage = prodImage;
	}
	public long getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(long merchantId) {
		this.merchantId = merchantId;
	}
	private String prodImage;
	private long merchantId;
}
