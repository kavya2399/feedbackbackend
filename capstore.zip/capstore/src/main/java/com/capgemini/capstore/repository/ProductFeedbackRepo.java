package com.capgemini.capstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.capstore.bean.ProductFeedback;


public interface ProductFeedbackRepo extends  JpaRepository<ProductFeedback,Long>{

}
