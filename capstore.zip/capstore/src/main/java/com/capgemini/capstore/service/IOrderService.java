package com.capgemini.capstore.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.bean.Carddetails;
import com.capgemini.capstore.bean.Customer_Orders;
import com.capgemini.capstore.bean.Product;
import com.capgemini.capstore.bean.ProductFeedback;
import com.capgemini.capstore.bean.Refund;
import com.capgemini.capstore.repository.CardRepo;
import com.capgemini.capstore.repository.OrderRepo;
import com.capgemini.capstore.repository.ProdRepo;
import com.capgemini.capstore.repository.ProductFeedbackRepo;
import com.capgemini.capstore.repository.RefundRepo;

@Service
public class IOrderService implements OrderService{

	@Autowired
	OrderRepo repo;
	@Autowired
	CardRepo repo1;
    @Autowired
    ProdRepo repo2;
    @Autowired
    RefundRepo repo3;
    @Autowired
ProductFeedbackRepo repo4;
	
	@Override
	public List<Customer_Orders> showOrders() {
		// TODO Auto-generated method stub
		List<Customer_Orders> list = new ArrayList<Customer_Orders>();
		list = repo.findAll();
		return list;
	}

	@Override
	public List<Carddetails> showDetails() {
		// TODO Auto-generated method stub
		List<Carddetails> list1 = new ArrayList<Carddetails>();
		list1 = repo1.findAll();
		return list1;
	}

	@Override
	public Carddetails insertCardDetails(Carddetails card) {
			Carddetails entity =  new Carddetails();
			entity.setCardNo(card.getCardNo());
			entity.setCard_holder_name(card.getCard_holder_name());
			entity.setCvv(card.getCvv());
			entity.setExpiry_year(card.getExpiry_year());
			entity.setExpiryMonth(card.getExpiryMonth());
		return repo1.saveAndFlush(card);
	}

	@Override
	public Product addProducts(Product prod) {
		// TODO Auto-generated method stub
		Product entity =  new Product();
		entity.setProdId(prod.getProdId());
		entity.setProdName(prod.getProdName());
		entity.setProdPrice(prod.getProdPrice());
		entity.setProdQuantity(prod.getProdQuantity());
		entity.setProdDiscount(prod.getProdDiscount());
		entity.setProdCategory(prod.getProdCategory());
		entity.setProdDesc(prod.getProdDesc());
		entity.setProdImage(prod.getProdImage());
		entity.setMerchantId(prod.getMerchantId());
	    return repo2.saveAndFlush(prod);
		
	}

	public List<Product> showProductDetails() {
		// TODO Auto-generated method stub
		List<Product> list1 = new ArrayList<Product>();
		list1 = repo2.findAll();
		return list1;
	}

	@Override
	public Refund addRefundDetails(Refund ref) {
		// TODO Auto-generated method stub
		Refund entity=new Refund();
		Customer_Orders cust=new Customer_Orders();
		entity.setCustomer_id(cust.getCustomerId());
		entity.setTransaction_id(cust.getOrderId());
		entity.setAmount(cust.getAmount());
		return repo3.saveAndFlush(entity);
	}

	/*public ProductFeedback addProductFeedback(ProductFeedback feed) {
		// TODO Auto-generated method stub
		ProductFeedback entity=new ProductFeedback();
		//ProductFeedback feed=new ProductFeedback();
		entity.setFeed_id(feed.getFeed_id());
		//entity.setProd_id(feed.getProdId());
		entity.setHeadline(feed.getHeadline());
		
		return repo4.saveAndFlush(entity);
		
	}

	public ProductFeedback addProductFeedback(Long prod_id) {
		long quantity=1;
		Product entity = new Product();
		
		Product wlist = repo2.findProduct(prod_id);
		
		return cartRepo.saveAndFlush(entity);
	}*/

	public ProductFeedback addProductFeedback(long prod_Id,ProductFeedback feedback) {
		//Product list = repo2.findProduct(prod_Id);
	//	System.out.println(list.getProdName());
		Optional<Product> list = repo2.findById(prod_Id);
		ProductFeedback feed = new ProductFeedback();
		if(list.isPresent()) {
			
			feed.setFeedback(feedback.getFeedback());
			feed.setHeadline(feedback.getHeadline());
			feed.setProd_id(prod_Id);
			return repo4.saveAndFlush(feed);
			
		}
		return null;
	}

	
	
	

	
}
