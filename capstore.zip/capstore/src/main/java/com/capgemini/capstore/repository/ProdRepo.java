package com.capgemini.capstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.capgemini.capstore.bean.Product;

public interface ProdRepo  extends JpaRepository<Product,Long>{
	//@Query("from product list where list.prod_Id = 1")
	//Product findProduct(@Param("prod_Id") long prod_Id);
	
	//@Query("from CartList list where list.prod_Id = :prod_Id")
		//CartList findByListId(@Param("prod_Id") Long prod_Id);

}
